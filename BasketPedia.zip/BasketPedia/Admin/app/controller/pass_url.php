<?php
header("Location: http://localhost/BasketPedia/Admin/Public/Login/");
?>