    <script src="<?= $header_path ?>/../Public/js/script.js"></script>
    <script src="<?= $header_path ?>/../Public/js/bootstrap/bootstrap.min.js"></script>
    <script src="<?= $header_path ?>/../Public/js/aos-master/dist/aos.js"></script>
    <script>AOS.init();</script>
  </body>
</html>