<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <title>BasketPedia | <?= $page->title ?></title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= $header_path ?>/../Public/css/bootsrap/bootstrap.min.css">
    <link rel="stylesheet" href="<?= $header_path ?>/../Public/css/default.css" />
    
    <link rel="icon" href="<?= $header_path ?>/../Public/images/logo/logo.png" type="image/x-icon" />
    <link href="<?= $header_path ?>/../Public/js/aos-master/dist/aos.css" rel="stylesheet">