<?php
$absolute_path = realpath($_SERVER["DOCUMENT_ROOT"])."/BasketPedia/Admin";
require "$absolute_path/app/controller/pass_url.php";
?>
