<?php

session_start();

$conn = mysqli_connect("localhost","root","","BasketPedia");
$query = mysqli_query($conn,"SELECT name,price,img FROM products");

if (!isset($_SESSION['session'])){
  header("Location: index.php");
}

function uploadImg(){
  $imgName = $_FILES['img']['name'];
  $error = $_FILES['img']['error'];
  $size = $_FILES['img']['size'];
  $locationUp = $_FILES['img']['tmp_name'];
  $formatFile = $_FILES['img']['type'];
  
  $format = "";
  $formatFix = "";
  // echo strlen($imgName);
  for ($i = strlen($imgName)-1; $i>=0; $i--){
    $format .= $imgName[$i];
    if ($imgName[$i] == ".") {
      break;
    }
  }
  for ($i=strlen($format)-1;$i>=0;$i--){
    $formatFix .= $format[$i];
  }
  
  $nameFix = ucwords($_POST['productName'].$formatFix);

  if ($error == 0 ){
    if ($size < 2000000){
      // echo $formatFile;
      if($formatFile == 'image/jpeg' || $formatFile == 'image/png'){
        move_uploaded_file($locationUp,'../images/products/'.$nameFix);
      }
      else{
        echo "<center><h1> format file harus jpg/png </h1></center>";
      }
    }
    else{
      echo "ukuran file terlalu besar";
    }
  }
  else{
    echo "file kegedean";
  }
}

if (isset($_POST['add'])){ // apabila tombol upload ditekan

  if ( $_FILES['img']['name'] != "" && $_POST['productName'] != "" && $_POST['price'] != ""  ){

    $imgName = $_FILES['img']['name'];
    
    $format = "";
    $formatFix = "";
    for ($i = strlen($imgName)-1; $i>=0; $i--){
      $format .= $imgName[$i];
      if ($imgName[$i] == ".") {
        break;
      }
    }
    for ($i=strlen($format)-1;$i>=0;$i--){
      $formatFix .= $format[$i];
    }
    
    $nameFix = ucwords($_POST['productName'].$formatFix);
    
    
    uploadImg();
    $productName = ucwords($_POST['productName']);
    $price = $_POST['price'];

    $size41 = $_POST['size41'];
    $size42 = $_POST['size42'];
    $size43 = $_POST['size43'];
    $size44 = $_POST['size44'];
    $size45 = $_POST['size45'];

    $query = mysqli_query($conn,"INSERT INTO products VALUES(0, '$productName', '$nameFix',$price)");
    $query = mysqli_query($conn,"INSERT INTO size VALUES(0, '$productName', 41, '$size41')");
    $query = mysqli_query($conn,"INSERT INTO size VALUES(0, '$productName', 42, '$size42')");
    $query = mysqli_query($conn,"INSERT INTO size VALUES(0, '$productName', 43, '$size43')");
    $query = mysqli_query($conn,"INSERT INTO size VALUES(0, '$productName', 44, '$size44')");
    $query = mysqli_query($conn,"INSERT INTO size VALUES(0, '$productName', 45, '$size45')");

    header("Location: store.php");
  }
  else{
    echo "<script>alert('form harus diisi lengkap!')</script>";
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Product</title>
  <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
  <link rel="stylesheet" href="../css/default.css" />
  <link rel="stylesheet" href="css/addProducts.css">
  <link rel="icon" href="../images/logo/logo.png" type="image/x-icon" />
  
</head>
<body>
  <!-- navbar Start -->
  <nav class="navbar navbar-expand-lg navbar-light shadow">
      <div class="container">
        <a class="navbar-brand" href="order.php"
          ><img src="img/logo/logo.png" alt=""
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="order.php">Order</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="store.php"
                >Store</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link" href="stok.php">Stok</a>
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                href="contact.php"
                tabindex="-1"
                aria-disabled="true"
                >Contact</a
              >
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- navbar end -->
  <div class="container">

    <form action="" method="POST" class="paymentForm"  enctype="multipart/form-data">
      <center><h1>Product Form</h1></center>
      <div class="product">
        
        <div class="value">
          <admin class="input">
            <label for="img">upload img</label>
            <input type="file"  name="img" style="font-size: 16px;">
            <label for="productName">Product Name</label>
            <input type="text" class="form-control" name="productName" placeholder="Product Name">
            <label for="price">Price</label>
            <input type="text" class="form-control" name="price" placeholder="Price">
            
            <label for="size">size and stok</label>
            <input type="text" class="form-control" placeholder="size41" name="size41">
            <input type="text" class="form-control" placeholder="size42" name="size42">
            <input type="text" class="form-control" placeholder="size43" name="size43">
            <input type="text" class="form-control" placeholder="size44" name="size44">
            <input type="text" class="form-control" placeholder="size45" name="size45">
          </admin/stok.phpdiv>
          
          <button type="submit" class="btn btn-outline-dark" name="add">Add Products</button>
          <br><br>
          

          
        </div>
      </div>
    </form>
    </div>
    
  </div>

  <script src="../js/script.js"></script>
</body>
</html>