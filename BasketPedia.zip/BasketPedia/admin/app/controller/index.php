<?php
  if ($_SESSION['session']){
    if ($_SESSION['session'] = 'true'){
      header("Location: order.php");
    }
  }

  if (isset($_POST['submit'])){
    
    if ($_POST['username'] == 'admin' && $_POST['password'] == '123' ){
      echo "<script>alert('anda admin!')</script>";
      $_SESSION['session'] = 'true';
      header("Location: index.php");
    }
    else{
      echo "<script>alert('anda bukan admin!')</script>";
    }
  }
  else{
    echo "<script>alert('silahkan login')</script>";
  }

?>