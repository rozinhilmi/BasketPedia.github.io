<?php 
  session_start();
  // session_destroy();
  if ($_SESSION['session']){
    if ($_SESSION['session'] = 'true'){
      header("Location: order.php");
    }
  }

  if (isset($_POST['submit'])){
    
    if ($_POST['username'] == 'admin' && $_POST['password'] == '123' ){
      echo "<script>alert('anda admin!')</script>";
      $_SESSION['session'] = 'true';
      header("Location: index.php");
    }
    else{
      echo "<script>alert('anda bukan admin!')</script>";
    }
  }
  else{
    echo "<script>alert('silahkan login')</script>";
  }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin | Login</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="css/default.css" />
    <link rel="stylesheet" href="css/index.css" />
    <link rel="icon" href="../images/logo/logo.png" type="image/x-icon" />

    <style>
      body {
        background-color: black;
        display: flex;
        flex-wrap: wrap;
        height: 100vh;
      }
      .formLogin {
        width: 700px;
        margin: auto;
        padding: 30px;
        color: white;
      }
    </style>
  </head>
  <body>
    <form class="formLogin" action="" method="POST">
      <h1 class="text-center">Admin</h1>
      <div class="mb-3">
        <label for="username" class="form-label">username</label>
        <input type="text" name="username" class="form-control" />
      </div>
      <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input
          type="password"
          name="password"
          class="form-control"
          id="exampleInputPassword1"
        />
      </div>

      <button type="submit" name="submit" class="btn btn-primary ctr">
        Submit
      </button>
    </form>
  </body>
</html>
