<?php
session_start();
// session_destroy();
$conn = mysqli_connect("localhost","root","","BasketPedia");



if (!isset($_SESSION['session'])){
  header("Location: index.php");
}


if (isset($_POST['accept'])){
  // echo $_POST['naindex.phpme']." ".$_POST['size'];
  $query = mysqli_query($conn,"UPDATE request set trackingNumber = '$_POST[trackingNumber]', message = '$_POST[message]', status = '$_POST[accept]' where id = '$_POST[id]'");
  header("Location: order.php");
}

if (isset($_POST['decline'])){
  $query = mysqli_query($conn,"UPDATE request set trackingNumber = '$_POST[trackingNumber]', message = '$_POST[message]', status = '$_POST[decline]' where id = '$_POST[id]'");
  $query = mysqli_query($conn,"SELECT stok from size where name = '$_POST[name]' and size = '$_POST[size]'");
  $stok = mysqli_fetch_assoc($query)['stok'];
  $stok+=1;
  $query = mysqli_query($conn,"UPDATE size SET stok = $stok where name = '$_POST[name]' and size = '$_POST[size]'");
  header("Location: order.php");
}

if (isset($_POST['update'])){
  $query = mysqli_query($conn,"UPDATE request set trackingNumber = '$_POST[trackingNumber]', message = '$_POST[message]' where id = '$_POST[id]'");
  header("Location: order.php");
}

if (isset($_POST['delete'])){
  $query = mysqli_query($conn,"DELETE FROM request WHERE id = '$_POST[id]'");
 
  $query = mysqli_query($conn,"	ALTER TABLE request DROP id
  ");
  $query = mysqli_query($conn,"	ALTER TABLE request ADD id INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST");
  header("Location: order.php");

}



?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="../css/default.css" />
    <link rel="stylesheet" href="css/table.css" />
    <link rel="icon" href="../images/logo/logo.png" type="image/x-icon" />
  </head>
  <body>
    <!-- navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light shadow">
      <div class="container">
        <a class="navbar-brand" href="order.php"
          ><img src="img/logo/logo.png" alt=""
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="order.php"
                >Order</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link" href="store.php">Store</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="stok.php">Stok</a>
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                href="contact.php"
                tabindex="-1"
                aria-disabled="true"
                >Contact</a
              >
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- navbar end -->

    <!-- table order Start -->
    <br /><br /><br />
    <div class="theTable">
      <center>
        <table class="table table-striped">
          <tr>
            <th>ID</th>
            <th>Name of Product</th>
            <th>Size</th>
            <th>Price</th>
            <th>Name of Customer</th>
            <th>Email</th>
            <th>Home Address</th>
            <th>Tracking Number</th>
            <th>Message</th>
            <th>Status</th>
            <th>Accept</th>
            <th>Decline</th>

            <th></th>
          </tr>
          <?php
          $query = mysqli_query($conn,"SELECT * FROM request ORDER by id DESC");
          while ($data = mysqli_fetch_assoc($query)){ ?>
          <form action="" method="POST">
            <tr>
              <td><?php echo $data['id']; ?></td>
              <input
                type="hidden"
                name="id"
                value="<?php echo $data['id']; ?>"
              />

              <td><?php echo $data['name']; ?></td>
              <td><?php echo $data['size']; ?></td>
              <td><?php echo $data['price']; ?></td>
              <td><?php echo $data['fullName']; ?></td>
              <td><?php echo $data['email']; ?></td>
              <td><?php echo $data['homeAddress']; ?></td>

              <td>
                <input
                  type="text"
                  name="trackingNumber"
                  value="<?php echo $data['trackingNumber'] ?>"
                  placeholder="<?php echo $data['trackingNumber'] ?>"
                />
              </td>

              <input
                type="hidden"
                name="name"
                value="<?php echo $data['name']; ?>"
              />
              <input
                type="hidden"
                name="size"
                value="<?php echo $data['size']; ?>"
              />

              <td>
                <input
                  type="text"
                  name="message"
                  value="<?php echo $data['message']; ?>"
                />
              </td>
              <td><?php echo $data['status']; ?></td>
              <?php
                if ($data['status'] != "rejected" ){ ?>
              <td>
                <button
                  type="submit"
                  class="btn btn-dark"
                  value="accepted"
                  name="accept"
                >
                  Accept
                </button>
              </td>
              <td>
                <button
                  type="submit"
                  class="btn btn-dark"
                  value="rejected"
                  name="decline"
                >
                  Decline
                </button>
              </td>

              <?php }
                else{ ?>
              <td>
                <button
                  type="submit"
                  class="btn btn-dark"
                  value="update"
                  name="update"
                >
                  update
                </button>
              </td>
              <td></td>
              <td>
                <button type="submit" class="btn btn-dark" name="delete">
                  X
                </button>
              </td>
              <?php }
              ?>
            </tr>
          </form>
          <?php } ?>
        </table>
      </center>
    </div>
    <!-- table order Enc -->

    <script src="../js/script.js"></script>
  </body>
</html>
