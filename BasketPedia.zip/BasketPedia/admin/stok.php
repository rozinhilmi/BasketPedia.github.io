<?php
session_start();
$conn = mysqli_connect("localhost","root","","BasketPedia");



if (!isset($_SESSION['session'])){
  header("Location: index.php");
}


if (isset($_POST['update'])){
  
  if ($_POST['stok'] != ""){
    echo $_POST['stok'] . "<br>" . $_POST['id'];
    $query = mysqli_query($conn,"UPDATE size SET stok = $_POST[stok] where id = $_POST[id]");
  }
  header("Location: stok.php");
}

if (isset($_GET['search'])){
  $query = mysqli_query($conn,"SELECT * FROM size where name like '%$_GET[search]%'");
}else{
  $query = mysqli_query($conn,"SELECT * FROM size");
}


?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="../css/default.css" />
    <link rel="stylesheet" href="css/table.css">
    <link rel="icon" href="../images/logo/logo.png" type="image/x-icon" />

    <title>Admin | Stok</title>
  </head>
  <body>
    <!-- navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light shadow">
      <div class="container">
        <a class="navbar-brand" href="order.php"
          ><img src="img/logo/logo.png" alt=""
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="order.php">Order</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="store.php"
                >Store</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link  active" href="stok.php">Stok</a>
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                href="contact.php"
                tabindex="-1"
                aria-disabled="true"
                >Contact</a
              >
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- navbar end -->
    <br><br><br>

    <form action="" method="get">
      <center>
        <input
          type="text"
          name="search"
          placeholder="Search Shoes"
          style="
            height: 35px;
            width: 200px;
            border: 1px solid grey;
            text-align: center;
          "
        />
      </center>
    </form>
    <br>
    <div class="theTable">
        <center>
          <table class="table table-striped">
            <tr>
              <th>ID</th>
              <th>Name of Product</th>
              <th>Size</th>
              <th>Stock Quantity</th>
              <th></th>
            
              
            </tr>
            <?php
            
            while ($data = mysqli_fetch_assoc($query)){ ?>
            <form action="" method="POST">
              <tr>
                <td><?php echo $data['id']; ?></td>
                <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                
                <td><?php echo $data['name']; ?></td>
                <td><?php echo $data['size']; ?></td>
                <td>
                  <input type="text" name="stok" placeholder="<?php echo $data['stok']; ?>">
                </td>
                
                <td>
                  <button type="submit" class="btn btn-dark" name="update">update</button>
                </td>

              </tr>
              </form>
            <?php } ?>
            
          </table>
        </center>
      </div>
    </div>

    <script src="../js/script.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
