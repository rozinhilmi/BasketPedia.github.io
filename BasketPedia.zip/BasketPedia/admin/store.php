<?php

session_start();
// session_destroy();
$conn = mysqli_connect("localhost","root","","BasketPedia");



if (!isset($_SESSION['session'])){
  header("Location: order.php");
}

if (isset($_GET['category'])){
  if ($_GET['taskOption'] == 'Price Lowest-Lowest'){
    $query = mysqli_query($conn,"SELECT id,name,price,img FROM products order by price");
  }
  else if ($_GET['taskOption'] == 'Price Highest-Lowest'){
    $query = mysqli_query($conn,"SELECT id,name,price,img FROM products order by price DESC");
  }
  else if ($_GET['taskOption'] == 'All'){
    $query = mysqli_query($conn,"SELECT id,name,price,img FROM products ORDER by id DESC");
  }

  else{
    $query = mysqli_query($conn,"SELECT id,name,price,img FROM products WHERE name like '%$_GET[taskOption]%' ORDER by id DESC");
  }
}
else{
  $query = mysqli_query($conn,"SELECT id,name,price,img FROM products ORDER by id DESC");
}


//kategory search
//=================================================================================================
if (isset($_GET['search'])){
	$query = mysqli_query($conn,"SELECT id,name,price,img FROM products where name like '%$_GET[search]%' ORDER by id DESC");
}


if (isset($_POST['change'])){
  // echo $_POST['nameBefore']."<br>";
  // echo $_POST['priceBefore']."<br>";
  // echo $_POST['name']."<br>";
  // echo $_POST['price']."<br>";

  $nameBefore = $_POST['nameBefore'];
  $name = ucwords($_POST['name']);
  $priceBefore = $_POST['priceBefore'];
  $price = $_POST['price'];
	

  $query = mysqli_query($conn,"UPDATE products SET name = '$name', price = '$price' where name = '$nameBefore' and price = $priceBefore");
  $query = mysqli_query($conn, "UPDATE size SET name = '$name' where name = '$nameBefore'");
  $query = mysqli_query($conn, "UPDATE request SET name = '$name' where name = '$nameBefore'");

	header("Location: store.php");

  
  
}

//delete product
if (isset( $_POST['delete'])){
	// echo $_POST['name']."<br>";
	// echo $_POST['img'];		
	$query = mysqli_query($conn,"DELETE FROM products where name like '%$_POST[name]%'");
	$query = mysqli_query($conn,"DELETE FROM size where name like '%$_POST[name]%'");
	$query = mysqli_query($conn,"ALTER TABLE products DROP id;");
	$query = mysqli_query($conn,"ALTER TABLE products ADD id INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST;");
	$query = mysqli_query($conn,"ALTER TABLE size DROP id;");
	$query = mysqli_query($conn,"ALTER TABLE size ADD id INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST;");
	unlink($_POST['img']);

	header("Location: store.php");
	
}


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="../css/default.css" />
    <link rel="stylesheet" href="css/store.css" />
    <link rel="icon" href="../images/logo/logo.png" type="image/x-icon" />

    <title>BasketPedia | Store</title>
  </head>
  <body>
    <!-- navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light shadow">
      <div class="container">
        <a class="navbar-brand" href="order.php"
          ><img src="img/logo/logo.png" alt=""
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="order.php">Order</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="store.php"
                >Store</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link" href="stok.php">Stok</a>
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                href="contact.php"
                tabindex="-1"
                aria-disabled="true"
                >Contact</a
              >
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- navbar end -->

    <div class="primeImg"></div>
    

    <!-- form category start -->
    <br><br><br><br>
    <center>
            <a href="addProducts.php" style="font-size : 30px;border : 1px solid black;padding:10px;">
              Add Products
            </a>
    </center>
    <br>
    <form class="formCategory" action="" method="get">
      <center>
        <select
          name="taskOption"
          class="form-select"
          aria-label="Default select example"
          style="width: 70%; float: left; margin-left: 40px"
        >
           <?php
            if (isset($_GET['taskOption'])){ ?>
              <option value="All" selected><?php echo $_GET['taskOption'] ?></option>
          <?php }
            else{ ?>
              <option value="All" selected>All</option>
          <?php } ?>
          <option value="Price Lowest-Lowest">Price Lowest-Highest</option>
          <option value="Price Highest-Lowest">Price Highest-Lowest</option>
          <option value="Air Jordan">Air Jordan</option>
          <option value="Kobe">Kobe</option>
          <option value="kyrie">Kyrie</option>
          <option value="Harden">Harden</option>
          <option value="Kevin Durant">Kevin Durant</option>
          <option value="Lebron">Lebron James</option>
          <option value="Paul George">Paul George</option>
          <option value="Freak">Freak</option>
          <option value="Curry">Curry</option>
          <option value="All">All</option>
        </select>

        <button class="btn btn-dark"
          type="submit"
          name="category"
          
        >
          go
        </button>

        <br /><br />
      </center>
    </form>
    <form action="" method="get">
      <center>
        <input
          type="text"
          name="search"
          placeholder="Search Shoes"
          class="form-control"
          style="
            height: 35px;
            width: 200px;
            border: 1px solid grey;
            text-align: center;
            
          "
        />
      </center>
    </form>
    <br />

    <!-- form category end -->
    <!-- store start -->
    <div class="store" id="store">
        

			<?php
				while ($data = mysqli_fetch_assoc($query)){

					$result = mysqli_query($conn,"select size,stok from size where name = '$data[name]'");

					// $size = mysqli_fetch_assoc($result);
					
					$stok = 0;
					while($count = mysqli_fetch_assoc($result)){
						$stok += $count['stok'];
					}
					if ($stok>0){ ?>
						<form action="" method="POST">
							<div class="boxStore">
									<input type="hidden" name="img" value="../images/products/<?php echo $data['img']; ?>">
                  <img  src="../images/products/<?php echo $data['img']; ?>" alt="">
                  <br><br>
                  <h1>
                    <input type="hidden" name= "nameBefore" value="<?php echo $data['name']; ?>">
                    <input type="text" class="form-control" name= "name" value="<?php echo $data['name']; ?>" placeholder="<?php echo $data['name']; ?>">
                </h1>
									<div class="harga">
                    <input type="hidden" name= "priceBefore" value="<?php echo $data['price']; ?>">
                    <input type="text" class="form-control" name= "price" value="<?php echo $data['price']; ?>">
                  </div>
									
                  <center>
                    <button type="submit" name="change" class="btn btn-dark">change</button>
                  </center>
									
									<center>

									<button name="delete" class="btn btn-dark">delete product</button>
									</center>
							</div>
						</form>
						
						

					<?php } ?>
				<?php } ?>	
		</div>
    <!-- store end -->

    <!-- myValue Start -->
    <div class="myValue"></div>
    <!-- myValue End -->

    <script src="../js/script.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
