<?php
header("Location: ".BASE_URL."/Public/Home/");
?>