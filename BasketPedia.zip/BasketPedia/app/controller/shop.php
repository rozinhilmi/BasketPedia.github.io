<?php
if (!isset($_GET['id'])){
	header("Location:store.php");
}
else{
	$query = mysqli_query($conn,"SELECT id,name,img,price from products where id = '$_GET[id]' ");
	$data = mysqli_fetch_assoc($query);

	$id = $data['id'];
	$name = $data['name'];
	$img = $data['img'];
	$price = $data['price'];

	if ($data == 0){
		header("Location: store.php");
	}
}

if (isset($_GET['submit'])){
	header("Location: payment.php?id=".$_GET['id']."&size=".$_GET['size']);
}
?>