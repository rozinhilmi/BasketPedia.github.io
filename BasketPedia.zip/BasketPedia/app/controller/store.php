<?php

if (isset($_GET['category'])){
  if ($_GET['taskOption'] == 'Price Lowest-Highest'){
    $query = mysqli_query($conn,"SELECT id,name,price,img FROM products order by price");
  }
  else if ($_GET['taskOption'] == 'Price Highest-Lowest'){
    $query = mysqli_query($conn,"SELECT id,name,price,img FROM products order by price DESC");
  }
  else if ($_GET['taskOption'] == 'All'){
    $query = mysqli_query($conn,"SELECT id,name,price,img FROM products ORDER by id DESC");
  }

  else{
    $query = mysqli_query($conn,"SELECT id,name,price,img FROM products WHERE name like '%$_GET[taskOption]%' ORDER by id DESC" );
  }
}
else{
  $query = mysqli_query($conn,"SELECT id,name,price,img FROM products ORDER by id DESC");
}


//kategory search
//=================================================================================================
if (isset($_GET['search'])){
	$query = mysqli_query($conn,"SELECT id,name,price,img FROM products where name like '%$_GET[search]%' ORDER by id DESC");
}


if (isset($_GET['message'])){
  echo $_GET['message'];
  // header("Location: store.php");
}
?>