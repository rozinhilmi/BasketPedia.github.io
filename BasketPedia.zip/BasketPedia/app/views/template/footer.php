    <script src="js/script.js"></script>
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <script src="js/aos-master/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
  </body>
</html>

