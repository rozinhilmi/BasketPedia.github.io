
    <script src="<?= BASE_URL ?>/Public/js/script.js?<?php echo time(); ?>"></script>
    <script src="<?= BASE_URL ?>/Public/js/bootstrap/bootstrap.min.js"></script>
    <script src="<?= BASE_URL ?>/Public/js/aos-master/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
  </body>
</html>

