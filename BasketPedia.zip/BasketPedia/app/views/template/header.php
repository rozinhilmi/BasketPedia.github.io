<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?= $page->title ?> | BasketPedia </title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>/Public/css/bootsrap/bootstrap.min.css" />
    <link rel="stylesheet" href="<?= BASE_URL ?>/Public/css/default.css" />
    <link rel="icon" href="<?= BASE_URL ?>/Public/images/logo/logo.png" type="image/x-icon" />
    <link href="<?= BASE_URL ?>/Public/js/aos-master/dist/aos.css" rel="stylesheet" />