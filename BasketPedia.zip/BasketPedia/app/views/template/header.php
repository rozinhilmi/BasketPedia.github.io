<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>BasketPedia | <?= $title ?></title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootsrap/bootstrap.min.css" />
    <link rel="stylesheet" href="css/default.css" />
    <link rel="icon" href="images/logo/logo.png" type="image/x-icon" />
    <link href="js/aos-master/dist/aos.css" rel="stylesheet" />