<?php
session_start();
session_destroy();
$conn = mysqli_connect("localhost","root","","BasketPedia");

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Status Order</title>
    <link rel="stylesheet" href="css/default.css" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link rel="icon" href="images/logo/logo.png" type="image/x-icon" />
    <style>
      table {
        display: block;
        width: 1000px;
        font-size: 15px;
      }
      td {
        font-size: 12px;
      }
    </style>
  </head>
  <body>
    <!-- navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light shadow">
      <div class="container">
        <a class="navbar-brand" href="index.html"
          ><img src="images/logo/logo.png" alt=""
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="store.php">Store</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="article.php">Article</a>
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                href="contact.php"
                tabindex="-1"
                aria-disabled="true"
                >Contact</a
              >
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- navbar end -->

    <div class="container">
      <center>
        <br /><br /><br />
        <form action="" method="POST">
          <div class="mb-3">
            <input
              type="text"
              name="customerOrder"
              placeholder="Input your full name here"
              class="form-control"
              style="text-align: center; padding: 4px; width: 500px"
            />
          </div>
          <button
            type="submit"
            name="getInfo"
            value="getInfo"
            style="
              border-radius: 30px;
              border: none;
              height: 30px;
              background-color: rgb(197, 197, 197);
            "
          >
            OK
          </button>
        </form>
      </center>
      <br /><br />

      <?php 
        if(isset($_POST['getInfo'])){ ?>
      <table class="table table-striped text-center">
        <tr>
          <th>ID</th>
          <th>Name of Product</th>
          <th>Size</th>
          <th>Price</th>
          <th>Name of Customer</th>
          <th>Email</th>
          <th>Home Address</th>
          <th>Tracking Number</th>
          <th>Message</th>
          <th>Status</th>
        </tr>
        <?php
        $query = mysqli_query($conn,"SELECT * FROM request where fullName = '$_POST[customerOrder]'");
        while ($data = mysqli_fetch_assoc($query)){ ?>

        <tr>
          <td><?php echo $data['id']; ?></td>

          <td><?php echo $data['name']; ?></td>
          <td><?php echo $data['size']; ?></td>
          <td><?php echo $data['price']; ?></td>
          <td><?php echo $data['fullName']; ?></td>
          <td><?php echo $data['email']; ?></td>
          <td><?php echo $data['homeAddress']; ?></td>

          <td><?php echo $data['trackingNumber'] ?></td>

          <td><?php echo $data['message']; ?></td>
          <td><?php echo $data['status']; ?></td>
        </tr>
        <?php } ?>
      </table>

      <?php }
      ?>
    </div>
    <script src="js/script.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
