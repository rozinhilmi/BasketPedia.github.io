<?php 
$title = "Home";
require "app/views/template/header.php";
?>
    <link rel="stylesheet" href="css/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="css/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="css/index.css" />

    <style>
      .swiper-container {
        width: 100%;
        /* width: 100vmin; */
        height: 100vh;
      }
      .swiper-slide {
        background-size: cover;
        background-position: center;
      }
      .swiper-1 {
        background-image: url('images/slider/slide1.jpg');
      }
      .swiper-2 {
        background-image: url('images/slider/slide2.jpg');
      }
      .swiper-3 {
        background-image: url('images/slider/slide3.jpg');
      }
      .swiper-4 {
        background-image: url('images/slider/slide4.jpg');
      }
      .swiper-5 {
        background-image: url('images/slider/slide5.jpg');
      }
      .swiper-6 {
        background-image: url('images/slider/slide6.jpg');
      }
      .heading-1 {
        position: absolute;
        z-index: 2;
        width: 100%;
        margin-top: 60vh;
        background-color: white;
      }
      .heading-1 h1 {
        margin-left: auto;
        margin-right: auto;
      }
      .brand-name {
        margin-top: 70vh;
        background-color: rgba(255, 255, 255, 0.5);
        color: black;
      }
      a {
        text-decoration: none;
      }
    </style>
  </head>
  <body>
    <!-- navbar Start -->
    <?php
      require 'app/views/template/navbar.php';
    ?>
    <!-- navbar end -->

    <!-- Slider main container -->
    <div class="swiper-container" data-aos="fade-down" data-aos-duration="1500">
      <div class="heading-1">
        <h1 class="text-center">New Arival</h1>
      </div>
      <!-- Additional required wrapper -->
      <div class="swiper-wrapper">
        <!-- Slides -->
        <a
          href="http://localhost/BasketPedia/shop.php?click=&id=4"
          class="swiper-slide swiper-1"
          ><h1 class="text-center brand-name">Kobe 6 Protro</h1></a
        >
        <a
          href="http://localhost/BasketPedia/shop.php?click=&id=8"
          class="swiper-slide swiper-2"
          ><h1 class="text-center brand-name">Kyrie Low 3</h1></a
        >
        <a
          href="http://localhost/BasketPedia/shop.php?click=&id=7"
          class="swiper-slide swiper-3"
          ><h1 class="text-center brand-name">Zoom Freak 2</h1></a
        >
        <a
          href="http://localhost/BasketPedia/shop.php?click=&id=10"
          class="swiper-slide swiper-4"
          ><h1 class="text-center brand-name">Lebron Soldier 14</h1></a
        >
        <a
          href="http://localhost/BasketPedia/shop.php?click=&id=5"
          class="swiper-slide swiper-5"
          ><h1 class="text-center brand-name">Lebron 18</h1></a
        >
      </div>
      <!-- If we need pagination -->
      <div class="swiper-pagination"></div>

      <!-- If we need navigation buttons -->
      <div class="swiper-button-prev"></div>
      <div class="swiper-button-next"></div>

      <!-- If we need scrollbar -->
      <div class="swiper-scrollbar"></div>
    </div>
    <!-- myValue Start -->
    <div class="myValue"></div>
    <!-- myValue End -->

    <script src="js/swiper/swiper-bundle.min.js"></script>
    <script src="js/swiper/swiper-bundle.js"></script>
    <script>
      const swiper = new Swiper('.swiper-container', {
        // Optional parameters
        direction: 'horizontal',
        loop: true,

        effect: 'flip',
        followFinger: 'true',
        allowTouchMove: 'true',

        // If we need pagination
        pagination: {
          el: '.swiper-pagination',
        },

        // Navigation arrows
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },

        // And if we need scrollbar
      });
    </script>
<?php
require "app/views/template/footer.php";
?>