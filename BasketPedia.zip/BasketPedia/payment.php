<?php
  $conn = mysqli_connect("localhost","root","","BasketPedia");
  $alert = "";
  if (!isset($_GET['id'])){
    header("Location: store.php");
  }
  else {

    $query = mysqli_query($conn,"SELECT id,name,price,img from products where id = '$_GET[id]'");
    
    $data = mysqli_fetch_assoc($query);
    $id = $data['id'];
    $name = $data['name'];
    $img = $data['img'];
  	$price = $data['price'];

    $validation = mysqli_query($conn,"SELECT stok from size where name = '$name' and size = '$_GET[size]' ");
    $result = mysqli_fetch_assoc($validation);
    if ($result['stok'] == 0 ){
      $message = "<script>alert('oops, stok yang anda cari baru saja habis')</script>"; 
      header("Location: store.php?message=$message"); 
    }
  }

  if (isset($_POST['buy'])){
    
    if (!$_POST['fullName']=="" && !$_POST['email']=="" && !$_POST['homeAddress']=="" ){
      
      $validation = mysqli_query($conn,"SELECT stok from size where name = '$name' and size = '$_GET[size]' ");
      $result = mysqli_fetch_assoc($validation);
      echo "<script>alert($result[stok])</script>";
      if ($result['stok'] <= 0 ){
        $message = "<script>alert('oops, stok yang anda cari baru saja habis')</script>"; 
        header("Location: store.php?message=$message"); 
      }
      else{
        $alert = "";
        $name = strip_tags($_POST['name']);
        $size = strip_tags($_POST['size']);
        $price = strip_tags($_POST['price']);
        $fullName = strip_tags($_POST['fullName']);
        $email = strip_tags($_POST['email']);
        $homeAddress = strip_tags($_POST['homeAddress']);
  
        $query = mysqli_query($conn,"INSERT INTO request values(0,'$name','$size','$price', '$fullName', '$email', '$homeAddress' ,'','','on request')");
  
        $query = mysqli_query($conn,"SELECT stok FROM size WHERE name = '$_POST[name]' and size = '$_POST[size]' ");
        if (mysqli_num_rows($query) > 0){
          $stok = mysqli_fetch_assoc($query)['stok'];
          $stok -= 1;
        }
        $query = mysqli_query($conn,"UPDATE size set stok = $stok WHERE name = '$_POST[name]' and size = '$_POST[size]' ");
        $_GET['name'] = '';
        $_GET['price'] = '';
        $_GET['size'] = '';
        $_GET['img'] = '';
  
        header("Location: getInfo.php");
      }
    }
    else{
      $alert = "all form must be filled";
    }
    
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BasketPedia | Payment</title>
  <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="css/default.css" />
    <link rel="stylesheet" href="css/payment.css" />
    <link rel="icon" href="images/logo/logo.png" type="image/x-icon" />


</head>
<body>
  <!-- navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light shadow">

      <div class="container">
        <a class="navbar-brand" href="index.html"
          ><img src="images/logo/logo.png" alt=""
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="store.php">Store</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="article.php">Article</a>
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                href="contact.php"
                tabindex="-1"
                aria-disabled="true"
                >Contact</a
              >
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- navbar end -->

    <!-- myPage start -->
    <div class="myPage">

      <form action="" method="POST" class="paymentForm">
        <center><h1>PAYMENT FORM</h1></center>
        <div class="product">
          <img src="images/products/<?php echo $data['img']; ?>" alt="">
          <div class="value">
            <div class="merk text-center"><?php
                echo $data['name'];
              ?>
            </div>
            
              
            <div class="harga text-center">IDR : <?php echo $data['price'] ?></div>
            <div class="harga text-center">size : <?php echo $_GET['size'] ?></div>

            <input type="hidden" name="img" value="<?php echo $data['img']; ?>">
            <input type="hidden" name="name" value="<?php echo $data['name']; ?>">
            <input type="hidden" name="price" value="<?php echo $data['price']; ?>">
            <input type="hidden" name="size" value="<?php echo $_GET['size']; ?>">

            <div class="input">
              <div class="mb-3">
                <label for="fullName" class="form-label">Full Name</label>
                <input type="text" name="fullName" class="form-control">
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email address</label>
                <input type="email" name="email" class="form-control">
              </div>
              <div class="mb-3">
                <label for="homeAddress" class="form-label">Home Address</label>
                <input type="text" name="homeAddress" class="form-control">
                <div id="emailHelp" class="form-text">We'll never share your information with anyone else.</div>
              </div>
            


              <!-- <label for="fullName">Full Name</label>
              <input type="text" name="fullName" placeholder="Full Name">
              <label for="email">Email</label>
              <input type="text" name="email" placeholder="Email">
              <label for="homeAddress">Home Address</label>
              <input type="text" name="homeAddress" placeholder="Home Address"> -->
            </div>
            
            <button type="submit" name="buy">Buy</button>
            <br><br>
            <h1><?php echo $alert; ?></h1>

            
          </div>
        </div>
      </form>
    </div>
    <!-- myPage end -->
    
  </div>

  <script src="js/script.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
  
</body>
</html>