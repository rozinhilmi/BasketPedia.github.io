<?php
  require "app/controller/connector_db.php";
  $alert = "";
  require "app/controller/payment.php";
  $title= "payment";
  require "app/views/template/header.php";
?>


  <link rel="stylesheet" href="css/payment.css" />
</head>
<body >
  <!-- navbar Start -->
  <?php
    require 'app/views/template/navbar.php';
  ?>
  <!-- navbar end -->

  <!-- myPage start -->
  <div class="myPage" data-aos="fade-down" data-aos-duration="1500">

    <form action="" method="POST" class="paymentForm">
      <center><h1>PAYMENT FORM</h1></center>
      <div class="product">
        <img src="images/products/<?php echo $data['img']; ?>" alt="">
        <div class="value">
          <div class="merk text-center"><?php
              echo $data['name'];
            ?>
          </div>
          
            
          <div class="harga text-center">IDR : <?php echo $data['price'] ?></div>
          <div class="harga text-center">size : <?php echo $_GET['size'] ?></div>

          <input type="hidden" name="img" value="<?php echo $data['img']; ?>">
          <input type="hidden" name="name" value="<?php echo $data['name']; ?>">
          <input type="hidden" name="price" value="<?php echo $data['price']; ?>">
          <input type="hidden" name="size" value="<?php echo $_GET['size']; ?>">

          <div class="input">
            <div class="mb-3">
              <label for="fullName" class="form-label">Full Name</label>
              <input type="text" name="fullName" class="form-control">
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email address</label>
              <input type="email" name="email" class="form-control">
            </div>
            <div class="mb-3">
              <label for="homeAddress" class="form-label">Home Address</label>
              <input type="text" name="homeAddress" class="form-control">
              <div id="emailHelp" class="form-text">We'll never share your information with anyone else.</div>
            </div>
          


            <!-- <label for="fullName">Full Name</label>
            <input type="text" name="fullName" placeholder="Full Name">
            <label for="email">Email</label>
            <input type="text" name="email" placeholder="Email">
            <label for="homeAddress">Home Address</label>
            <input type="text" name="homeAddress" placeholder="Home Address"> -->
          </div>
          
          <button type="submit" name="buy">Buy</button>
          <br><br>
          <h1><?php echo $alert; ?></h1>

          
        </div>
      </div>
    </form>
  </div>
  <!-- myPage end -->
    
<?php
require "app/views/template/footer.php";
?>