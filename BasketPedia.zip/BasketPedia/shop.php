<?php
require "app/controller/connector_db.php";
require "app/controller/shop.php";
$title = "Shop";
require "app/views/template/header.php";
?>


    <link rel="stylesheet" href="css/shop.css?v=<?php echo time(); ?>" />
  </head>
  <body>
    <!-- navbar Start -->
    <?php
      require 'app/views/template/navbar.php';
    ?>
    <!-- navbar end -->

    <!-- container start -->
    <center>
      <div class="sizeChart">
        <img src="images/sizeChart.jpg" alt="" />
        <button onclick="sizeChart()">X</button>
      </div>
    </center>
    <div class="container" data-aos="fade-down" data-aos-duration="1500">
      <form action="" method="GET" class="contain">
        <div class="gambar">
          <img src="images/products/<?php echo $img ?>" alt="" />
        </div>
        <div class="formPembayaran">
          <center>
            <div class="merk">
              <?php
						echo $name;
					?>
            </div>
            <input type="hidden" name="id" value="<?php echo $id; ?>" />
            <br /><br />
            <div class="harga">
              IDR :
              <?php echo $price ?>
            </div>
            <br /><br />
            <label for="size"><h1>Size :</h1></label>

            <select name="size" id="">
              <?php
							$query = mysqli_query($conn,"SELECT name from products where id = $id");
							$nameOfSize = mysqli_fetch_assoc($query)['name'];
							$query = mysqli_query($conn,"SELECT size FROM size where name = '$nameOfSize' and stok>0");
              while ($data = mysqli_fetch_assoc($query)){ ?>
              <option value="<?php echo $data['size']; ?>">
                <h2><?php echo $data['size']; ?></h2>
              </option>
              <?php } ?>
            </select>
            <br />

            <br />
            <button type="submit" name="submit">Buy</button><br />
            
          </center>
        </div>
      </form>
      <button class="sizeButton" onclick="sizeChart()">view size chart</button>
      
    </div>
    <!-- container end -->

<?php
require "app/views/template/footer.php";
?>