<?php
$conn = mysqli_connect("localhost","root","","BasketPedia");
if (!isset($_GET['id'])){
	header("Location:store.php");
}
else{
	$query = mysqli_query($conn,"SELECT id,name,img,price from products where id = '$_GET[id]' ");
	$data = mysqli_fetch_assoc($query);

	$id = $data['id'];
	$name = $data['name'];
	$img = $data['img'];
	$price = $data['price'];

	if ($data == 0){
		header("Location: store.php");
	}
}

if (isset($_GET['submit'])){
	header("Location: payment.php?id=".$_GET['id']."&size=".$_GET['size']);
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>BasketPedia | Shop</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css?v=<?php echo time(); ?>"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="css/default.css?v=<?php echo time(); ?>" />
    <link rel="stylesheet" href="css/shop.css?v=<?php echo time(); ?>" />
    <link rel="icon" href="images/logo/logo.png" type="image/x-icon" />
  </head>
  <body>
    <!-- navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light shadow">
      <div class="container">
        <a class="navbar-brand" href="index.html"
          ><img src="images/logo/logo.png" alt=""
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="store.php">Store</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="article.php">Article</a>
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                href="contact.php"
                tabindex="-1"
                aria-disabled="true"
                >Contact</a
              >
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- navbar end -->

    <!-- container start -->
    <center>
      <div class="sizeChart">
        <img src="images/sizeChart.jpg" alt="" />
        <button onclick="sizeChart()">X</button>
      </div>
    </center>
    <div class="container">
      <form action="" method="GET" class="contain">
        <div class="gambar">
          <img src="images/products/<?php echo $img ?>" alt="" />
        </div>
        <div class="formPembayaran">
          <center>
            <div class="merk">
              <?php
						echo $name;
					?>
            </div>
            <input type="hidden" name="id" value="<?php echo $id; ?>" />
            <br /><br />
            <div class="harga">
              IDR :
              <?php echo $price ?>
            </div>
            <br /><br />
            <label for="size"><h1>Size :</h1></label>

            <select name="size" id="">
              <?php
							$query = mysqli_query($conn,"SELECT name from products where id = $id");
							$nameOfSize = mysqli_fetch_assoc($query)['name'];
							$query = mysqli_query($conn,"SELECT size FROM size where name = '$nameOfSize' and stok>0");
              while ($data = mysqli_fetch_assoc($query)){ ?>
              <option value="<?php echo $data['size']; ?>">
                <h2><?php echo $data['size']; ?></h2>
              </option>
              <?php } ?>
            </select>
            <br />

            <br />
            <button type="submit" name="submit">Buy</button><br />
          </center>
        </div>
      </form>
      <button class="sizeButton" onclick="sizeChart()">view size chart</button>
    </div>
    <!-- container end -->

    <script src="js/script.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
      crossorigin="anonymous"
    ></script>
  </body>
</html>