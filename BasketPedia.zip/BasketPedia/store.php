<?php
session_start();
require "app/controller/connector_db.php";
require "app/controller/store.php";
?>

<?php
$title = "Store";
require "app/views/template/header.php";
?>
    <link rel="stylesheet" href="css/store.css" />
  </head>
  <body>
    <!-- navbar Start -->
    <?php
      require 'app/views/template/navbar.php';
      // showNavbar();
    ?>
    <!-- navbar end -->

    <div class="primeImg"  data-aos="fade-down" data-aos-duration="1500"></div>

    <!-- form category start -->
    <br />
    <form class="formCategory" action="" method="get">
      <center>
        <select
          name="taskOption"
          class="form-select"
          aria-label="Default select example"
          style="width: 70%; float: center;"
          onchange="clicked()"
          id="select_value"
        >
          <?php
            if (isset($_GET['taskOption'])){ ?>
              <option value="All" selected><?php echo $_GET['taskOption'] ?></option>
          <?php }
            else{ ?>
              <option value="All" selected>All</option>
          <?php } ?>
          
          <option value="Price Lowest-Highest">Price Lowest-Highest</option>
          <option value="Price Highest-Lowest">Price Highest-Lowest</option>
          <option value="Air Jordan">Air Jordan</option>
          <option value="Kobe">Kobe</option>
          <option value="kyrie">Kyrie</option>
          <option value="Harden">Harden</option>
          <option value="Kevin Durant">Kevin Durant</option>
          <option value="Lebron">Lebron James</option>
          <option value="Paul George">Paul George</option>
          <option value="Freak">Freak</option>
          <option value="Curry">Curry</option>
          <option value="All">All</option>
        </select>

        <br /><br />
      </center>
    </form>
    <form action="" method="get" class="search">
      <center>
        <input
          type="text"
          name="search"
          placeholder="Search Shoes"
          class="form-control"
          style="
            height: 35px;
            width: 300px;
            border: 1px solid grey;
            text-align: center;
            
          "
        />
      </center>
    </form>
    <br />

    <!-- form category end -->
    <!-- store start -->
    <div class="store" id="store">
      <?php
				while ($data = mysqli_fetch_assoc($query)){

					$result = mysqli_query($conn,"SELECT stok from size where name = '$data[name]'");
					$stok = 0;
					while($count = mysqli_fetch_assoc($result)){
						$stok += $count['stok'];
					}
					if ($stok>0){ ?>
            <form action="shop.php" method="GET">
              <button class="boxStore shadow p-3 mb-5 bg-body rounded" type="submit" name="click" data-aos-duration = "500" data-aos="flip-left" >
                <img src="images/products/<?php echo $data['img']; ?>" alt="" />
                <h1><?php echo $data['name']; ?></h1>
                <div class="harga">
                  IDR :
                  <?php echo $data['price']; ?>
                </div>
                <input type="hidden" name="id" value="<?php echo $data['id']; ?>" />
              </button>
            </form>

      <?php } ?>
      <?php } ?>
    </div>
    <!-- store end -->

    <!-- myValue Start -->
    <div class="myValue"></div>
    <!-- myValue End -->

    
    <script>
      function clicked(){
        selected = document.getElementById("select_value").value;
        window.location.replace("store.php?taskOption="+selected+"&category=");
      }
    </script>

<?php
require "app/views/template/footer.php";
?>